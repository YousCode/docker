<?php
include "server.php";
?>

<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
</head>

<body>
  <?php
  while ($row = $reponse->fetch(PDO::FETCH_ASSOC)) : ?>
    <td>
      <?php 
        echo json_encode($row['ID']);
        echo json_encode($row['Username']);
        echo json_encode($row['Email']);
        echo json_encode($row['password']);
       ?>
    </td>
  <?php endwhile; ?>
  <tbody>

</html>